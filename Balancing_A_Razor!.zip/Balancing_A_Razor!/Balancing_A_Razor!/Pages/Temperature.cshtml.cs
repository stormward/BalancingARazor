using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Balancing_A_Razor_.Pages
{
    public class TempModel : PageModel
    {
        [BindProperty]
        public string TempType { get; set; }
        public int TempInput { get; set; }
        public string result;

        public void OnPost(int tempInput)
        {
            TempInput = tempInput;
            if (TempType == "1")
            {
              result = "F 2 C conversion Result: " + (tempInput - 32) * 5 / 9 + " degrees";
            }

            if (TempType == "2")
            {
                result = "C 2 F conversion result: " + ((tempInput * 9 / 5) + 32) + " degrees";
            }
        }

    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Balancing_A_Razor_.Pages
{
    public class MassModel : PageModel
    {
        [BindProperty]
        public string MassType { get; set; }
        public int MassInput { get; set; }
        public string result;

        public void OnPost(int massInput)
        {
            MassInput = massInput;
            if (MassType == "1")
            {
                result = "F 2 C conversion Result: " + (massInput * 16) + " Ounces";
            }

            if (MassType == "2")
            {
                result = "C 2 F conversion result: " + (massInput / 16) + " Pounds";
            }

            if (MassType == "3")
            {
                result = "C 2 F conversion result: " + (massInput / 454) + " Pounds";
            }

            if (MassType == "4")
            {
                result = "C 2 F conversion result: " + (massInput / 453592) + " Pounds";
            }
        }
    }
}